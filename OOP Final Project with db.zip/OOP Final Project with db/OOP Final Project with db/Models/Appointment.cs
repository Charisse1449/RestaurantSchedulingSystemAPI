﻿namespace OOP_Final_Project_with_db.Models
{
    public class Appointment
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public string RestaurantID { get; set; }
        public DateTime AppointmentDate { get; set; }
        public int NumberOfPeople { get; set; }
        public string Status { get; set; }
    }
}
