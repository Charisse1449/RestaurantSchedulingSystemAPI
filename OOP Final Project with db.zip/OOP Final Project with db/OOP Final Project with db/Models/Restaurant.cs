﻿namespace OOP_Final_Project_with_db.Models
{
    public class Restaurant
    {
        public int RestuarantID { get; set; }
        public string RestaurantName { get; set; }
        public string RestaurantAddress { get; set; }
        public string RestaurantEmail { get; set; }
        public int RestaurantPhoneNumber { get; set; }
        
    }
}
