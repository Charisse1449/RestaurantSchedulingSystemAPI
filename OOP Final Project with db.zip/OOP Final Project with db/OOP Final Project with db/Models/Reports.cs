﻿namespace OOP_Final_Project_with_db.Models
{
    public class Reports
    {
        public int ReportID { get; set; }
        public int RestaurantID { get; set; }
        public DateTime ReportDate { get; set; }
        public int TotalAppointments { get; set; }
        public int CancelledAppointments { get; set; }
        public int CompletedAppointments { get; set; }
    }
}
