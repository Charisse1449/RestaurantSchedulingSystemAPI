﻿namespace OOP_Final_Project_with_db.Models
{
    public class Staff
    {
        public int StaffId { get; set; }
        public string StaffFName { get; set; }
        public string StaffLName { get; set;}
        public string StaffRole {  get; set; }
    }
}
