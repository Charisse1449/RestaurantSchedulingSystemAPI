﻿namespace OOP_Final_Project_with_db.Models
{
    public class Costumers
    {
        public int CostumerId{ get; set; }
        public string CostumerFName{ get; set; }
        public string CostumerLName { get; set; }
        public string CostumerEmail { get; set; }
        public string CostumerPNumber { get; set; }
        public DateTime DateRegistered { get; set; }

    }
}
