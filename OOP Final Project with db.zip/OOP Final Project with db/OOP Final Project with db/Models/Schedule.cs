﻿namespace OOP_Final_Project_with_db.Models
{
    public class Schedule
    {
        public int ScheduleID { get; set; }
        public int RestaurantID { get; set; }
        public Enum DayOfWeek { get; set; }
        public TimeOnly OpeningTime { get; set; }
        public TimeOnly ClosingTime { get; set; }
    }
}
