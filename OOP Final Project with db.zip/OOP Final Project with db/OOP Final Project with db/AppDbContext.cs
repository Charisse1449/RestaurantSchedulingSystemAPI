﻿using Microsoft.EntityFrameworkCore;
using OOP_Final_Project_with_db.Models;
namespace OOP_Final_Project_with_db
{
    public class AppDbContext : DbContext
    {
        // Constructor that takes DbContextOptions and passes them to the base constructor
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        // DbSet for each entity (e.g., Appointments)
        public DbSet<Costumers> Costumers { get; set; }

        public DbSet<Appointment> Appointments { get; set; }
        public DbSet<Restaurant> Restaurants { get; set; }
        public DbSet<Reports> Reports { get; set; }



    }
}
