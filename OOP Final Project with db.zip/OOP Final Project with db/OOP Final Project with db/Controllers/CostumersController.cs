﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OOP_Final_Project_with_db.Models;

namespace OOP_Final_Project_with_db.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CostumersController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CostumersController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Costumers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Costumers>>> GetCostumers()
        {
            return await _context.Costumers.ToListAsync();
        }

        // GET: api/Costumers/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<Costumers>> GetCostumer(int id)
        {
            var costumer = await _context.Costumers.FindAsync(id);

            if (costumer == null)
            {
                return NotFound();
            }

            return costumer;
        }

        // POST: api/Costumers
        [HttpPost]
        public async Task<ActionResult<Costumers>> PostCostumer(Costumers costumer)
        {
            _context.Costumers.Add(costumer);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCostumer), new { id = costumer.CostumerId }, costumer);
        }

        // PUT: api/Costumers/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCostumer(int id, Costumers costumer)
        {
            if (id != costumer.CostumerId)
            {
                return BadRequest();
            }

            _context.Entry(costumer).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CostumerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/Costumers/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCostumer(int id)
        {
            var costumer = await _context.Costumers.FindAsync(id);
            if (costumer == null)
            {
                return NotFound();
            }

            _context.Costumers.Remove(costumer);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CostumerExists(int id)
        {
            return _context.Costumers.Any(e => e.CostumerId == id);
        }
    }
}
